/*  Audacious - Cross-platform multimedia player
 *  Copyright (C) 2005-2011  Audacious development team.
 *
 *  BMP - Cross-platform multimedia player
 *  Copyright (C) 2003-2004  BMP development team.
 *
 *  Based on XMMS:
 *  Copyright (C) 1998-2003  XMMS development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; under version 3 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses>.
 *
 *  The Audacious team does not consider modular code linking to
 *  Audacious or using our public API to be a derived work.
 */

#include "actions-mainwin.h"
#include "actions-playlist.h"
#include "main.h"
#include "plugin-window.h"

#include <gtk/gtk.h>

#include <libaudcore/drct.h>
#include <libaudcore/i18n.h>
#include <libaudcore/playlist.h>
#include <libaudcore/plugins.h>
#include <libaudgui/libaudgui.h>

#define ACTIVE (Playlist::active_playlist ())

void action_ab_clear ()
{
    mainwin_show_status_message (_("Repeat points cleared."));
    aud_drct_set_ab_repeat (-1, -1);
}

void action_ab_set ()
{
    if (aud_drct_get_length () > 0)
    {
        int a, b;
        aud_drct_get_ab_repeat (a, b);

        if (a < 0 || b >= 0)
        {
            a = aud_drct_get_time ();
            b = -1;
            mainwin_show_status_message (_("Repeat point A set."));
        }
        else
        {
            b = aud_drct_get_time ();
            mainwin_show_status_message (_("Repeat point B set."));
        }

        aud_drct_set_ab_repeat (a, b);
    }
}

void action_play_file ()
    { audgui_run_filebrowser (true); }
void action_play_location ()
    { audgui_show_add_url_window (true); }

static void enable_and_focus_plugin (const char * name)
{
    PluginHandle * plugin = aud_plugin_lookup_basename (name);
    if (plugin)
    {
        aud_plugin_enable (plugin, true);
        focus_plugin_window (plugin);
    }
}

#ifdef HAVE_PLAYBACK_HISTORY
void action_playback_history ()
    { enable_and_focus_plugin ("playback-history"); }
#endif
#ifdef HAVE_PLAYLIST_MANAGER
void action_playlist_manager ()
    { enable_and_focus_plugin ("playlist-manager"); }
#endif
#ifdef HAVE_SEARCH_TOOL
void action_search_tool ()
    { enable_and_focus_plugin ("search-tool"); }
#endif

void action_playlist_rename ()
    { audgui_show_playlist_rename (ACTIVE); }
void action_playlist_delete ()
    { audgui_confirm_playlist_delete (ACTIVE); }

void action_playlist_add_url ()
    { audgui_show_add_url_window (false); }
void action_playlist_add_files ()
    { audgui_run_filebrowser (false); }
