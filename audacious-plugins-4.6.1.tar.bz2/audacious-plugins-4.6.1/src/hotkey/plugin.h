#ifndef _PLUGIN_H_INCLUDED_
#define _PLUGIN_H_INCLUDED_

#define TYPE_KEY 0
#define TYPE_MOUSE 1

/*
 * Add new events always at the end of the enum (but before EVENT_MAX).
 * The int values are used in the configuration and hence should not change.
 */
typedef enum
{
    EVENT_PREV_TRACK = 0,
    EVENT_PLAY,
    EVENT_PAUSE,
    EVENT_STOP,
    EVENT_NEXT_TRACK,

    EVENT_FORWARD,
    EVENT_BACKWARD,
    EVENT_MUTE,
    EVENT_VOL_UP,
    EVENT_VOL_DOWN,
    EVENT_JUMP_TO_FILE,
    EVENT_TOGGLE_WIN,
    EVENT_SHOW_AOSD,

    EVENT_TOGGLE_REPEAT,
    EVENT_TOGGLE_SHUFFLE,
    EVENT_TOGGLE_STOP,

    EVENT_RAISE,

    EVENT_PREV_ALBUM,
    EVENT_NEXT_ALBUM,

    EVENT_MAX
} EVENT;

typedef struct _HotkeyConfiguration
{
    unsigned key, mask;
    unsigned type;
    EVENT event;
    struct _HotkeyConfiguration * next;
} HotkeyConfiguration;

typedef struct
{
    /* keyboard */
    HotkeyConfiguration first;
} PluginConfig;

void load_config();
void save_config();
PluginConfig * get_config();
bool handle_keyevent(EVENT event);

#endif
